cube(1);
